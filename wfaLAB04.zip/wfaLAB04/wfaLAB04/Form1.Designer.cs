﻿namespace wfaLAB04
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbV1x = new System.Windows.Forms.TextBox();
            this.tbV1z = new System.Windows.Forms.TextBox();
            this.tbV1y = new System.Windows.Forms.TextBox();
            this.tbV2x = new System.Windows.Forms.TextBox();
            this.tbV2y = new System.Windows.Forms.TextBox();
            this.tbV2z = new System.Windows.Forms.TextBox();
            this.tbModuloV1 = new System.Windows.Forms.TextBox();
            this.tbEscalarV1V2 = new System.Windows.Forms.TextBox();
            this.tbModuloV2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbV1x
            // 
            this.tbV1x.Location = new System.Drawing.Point(40, 23);
            this.tbV1x.Name = "tbV1x";
            this.tbV1x.Size = new System.Drawing.Size(100, 20);
            this.tbV1x.TabIndex = 0;
            // 
            // tbV1z
            // 
            this.tbV1z.Location = new System.Drawing.Point(40, 75);
            this.tbV1z.Name = "tbV1z";
            this.tbV1z.Size = new System.Drawing.Size(100, 20);
            this.tbV1z.TabIndex = 1;
            // 
            // tbV1y
            // 
            this.tbV1y.Location = new System.Drawing.Point(40, 49);
            this.tbV1y.Name = "tbV1y";
            this.tbV1y.Size = new System.Drawing.Size(100, 20);
            this.tbV1y.TabIndex = 2;
            // 
            // tbV2x
            // 
            this.tbV2x.Location = new System.Drawing.Point(40, 145);
            this.tbV2x.Name = "tbV2x";
            this.tbV2x.Size = new System.Drawing.Size(100, 20);
            this.tbV2x.TabIndex = 3;
            // 
            // tbV2y
            // 
            this.tbV2y.Location = new System.Drawing.Point(39, 171);
            this.tbV2y.Name = "tbV2y";
            this.tbV2y.Size = new System.Drawing.Size(100, 20);
            this.tbV2y.TabIndex = 4;
            // 
            // tbV2z
            // 
            this.tbV2z.Location = new System.Drawing.Point(40, 197);
            this.tbV2z.Name = "tbV2z";
            this.tbV2z.Size = new System.Drawing.Size(100, 20);
            this.tbV2z.TabIndex = 5;
            // 
            // tbModuloV1
            // 
            this.tbModuloV1.Location = new System.Drawing.Point(220, 49);
            this.tbModuloV1.Name = "tbModuloV1";
            this.tbModuloV1.Size = new System.Drawing.Size(100, 20);
            this.tbModuloV1.TabIndex = 6;
            // 
            // tbEscalarV1V2
            // 
            this.tbEscalarV1V2.Location = new System.Drawing.Point(220, 109);
            this.tbEscalarV1V2.Name = "tbEscalarV1V2";
            this.tbEscalarV1V2.Size = new System.Drawing.Size(100, 20);
            this.tbEscalarV1V2.TabIndex = 7;
            // 
            // tbModuloV2
            // 
            this.tbModuloV2.Location = new System.Drawing.Point(220, 168);
            this.tbModuloV2.Name = "tbModuloV2";
            this.tbModuloV2.Size = new System.Drawing.Size(100, 20);
            this.tbModuloV2.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Y";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Z";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(37, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Vetor 1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 129);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Vetor 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(217, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Modulo Vetor 2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(217, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Modulo Vetor 1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(217, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Escalar V1 e V2";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Z";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Y";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "X";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(142, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = "Calcular";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 261);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbModuloV2);
            this.Controls.Add(this.tbEscalarV1V2);
            this.Controls.Add(this.tbModuloV1);
            this.Controls.Add(this.tbV2z);
            this.Controls.Add(this.tbV2y);
            this.Controls.Add(this.tbV2x);
            this.Controls.Add(this.tbV1y);
            this.Controls.Add(this.tbV1z);
            this.Controls.Add(this.tbV1x);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbV1x;
        private System.Windows.Forms.TextBox tbV1z;
        private System.Windows.Forms.TextBox tbV1y;
        private System.Windows.Forms.TextBox tbV2x;
        private System.Windows.Forms.TextBox tbV2y;
        private System.Windows.Forms.TextBox tbV2z;
        private System.Windows.Forms.TextBox tbModuloV1;
        private System.Windows.Forms.TextBox tbEscalarV1V2;
        private System.Windows.Forms.TextBox tbModuloV2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
    }
}

